#!/bin/bash

# Set DEBUG=True for faster pic and status update
# DEBUG=True ../moonraker-obico-env/bin/python3 -m moonraker_obico.app $@

../moonraker-obico-env/bin/python3 -m moonraker_obico.app $@
